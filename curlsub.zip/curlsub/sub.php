<?php
include 'curl.php';
include 'user.php';
login("http://www.fbtakip.com/takipci/verify.php?user=".$token1."","null");
echo post_data("http://www.fbtakip.com/takipci/f.php?type=custom","id=".$UID."&limit=50&submit=Submit");

login("http://www.fbtakip.com/takipci/verify.php?user=".$token2."","null");
echo post_data("http://www.fbtakip.com/takipci/f.php?type=custom","id=".$UID."&limit=50&submit=Submit");

login("http://www.fbtakip.com/takipci/verify.php?user=".$token3."","null");
echo post_data("http://www.fbtakip.com/takipci/f.php?type=custom","id=".$UID."&limit=50&submit=Submit");

login("http://www.fbtakip.com/takipci/verify.php?user=".$token4."","null");
echo post_data("http://www.fbtakip.com/takipci/f.php?type=custom","id=".$UID."&limit=50&submit=Submit");

login("http://www.fbtakip.com/takipci/verify.php?user=".$token5."","null");
echo post_data("http://www.fbtakip.com/takipci/f.php?type=custom","id=".$UID."&limit=50&submit=Submit");
?>
