<?php
$dataLog  =  array(
'email' => '100014044567912', // Tài khoản Facebook
'pass' => '797979', // Mật khẩu Facebook
'apps' =>'41158896424',# ID App Token
);
$dataLog2  =  array(
'email' => 'nguyen.khanhlinh.58726823', // Tài khoản Facebook
'pass' => '797979', // Mật khẩu Facebook
'apps' =>'41158896424',# ID App Token
);
$dataLog3  =  array(
'email3' => 'nguyen.khanhlinh.73932646', // Tài khoản Facebook
'pass3' => '797979', // Mật khẩu Facebook
'apps3' =>'41158896424',# ID App Token
);
$dataLog4  =  array(
'email' => '100014056567772', // Tài khoản Facebook
'pass' => '797979', // Mật khẩu Facebook
'apps' =>'41158896424',# ID App Token
);
$dataLog5  =  array(
'email' => '100014158295760', // Tài khoản Facebook
'pass' => '797979', // Mật khẩu Facebook
'apps' =>'41158896424',# ID App Token
);

?>