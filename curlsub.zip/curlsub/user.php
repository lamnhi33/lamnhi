<?php

$domain = 'http://autocurl.tk';
$email = '01297427428';
$pass = 'Kid123456789';
$limitsub ='700000';

 $UID ='100009859624773';
 $location ='1';
 $type ='1'; 
$token1= file_get_contents('/token/token1.txt');
$token2= file_get_contents('/token/token2.txt');
$token3= file_get_contents('/token/token3.txt');
$token4= file_get_contents('/token/token4.txt');
$token5= file_get_contents('/token/token5.txt');
?>