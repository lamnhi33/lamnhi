<?php
$domain= 'http://autocurl.tk/token';
ds(''.$domain.'/1.php');
ds(''.$domain.'/2.php');
ds(''.$domain.'/3.php');
ds(''.$domain.'/4.php');
ds(''.$domain.'/5.php');

function ds($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }
?>